"""Verify the frozen evidence and reproduce the normalization comparison offline."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import stat
import subprocess
import sys
import zipfile
from analyze_readout import analyze

ROOT = Path(__file__).resolve().parent
EVIDENCE_SHA256 = 'f3b9d8ea845cb160ac9470f44fb0e63b5e9b338b40bc30f33c6a8b497f09d963'

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True, help='New directory; existing paths are rejected.')
    args = p.parse_args()
    out = args.out.resolve()
    if out.exists(): p.error('Output already exists. Choose a new path.')
    archive = ROOT / 'QwenQPU-review-experiments-complete-20261113.zip'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == EVIDENCE_SHA256
    manifest = ROOT / 'MANIFEST.json'
    if manifest.exists():
        for name, expected in json.loads(manifest.read_text())['files'].items():
            item = PurePosixPath(name)
            assert not item.is_absolute() and '..' not in item.parts
            assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected, name
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        names = z.namelist(); assert len(names) == len(set(names))
        for entry in z.infolist():
            name = PurePosixPath(entry.filename)
            assert not name.is_absolute() and '..' not in name.parts
            assert not stat.S_ISLNK(entry.external_attr >> 16)
        out.mkdir(parents=True, exist_ok=False)
        evidence = out / 'evidence'; evidence.mkdir()
        z.extractall(evidence)
    run = subprocess.run([sys.executable, str(evidence/'audit_final_results.py'), '--out', str(out/'state-and-control-audit')],
                         check=True, capture_output=True, text=True)
    (out/'state-and-control-audit.log').write_text(run.stdout)
    summary = analyze(evidence, out/'readout-audit')
    receipt = json.loads((out/'state-and-control-audit/verification.json').read_text())
    assert receipt['paired_tasks_verified'] == 48 and receipt['capacity_cases_verified'] == 36
    assert receipt['per_gate_state_snapshots_independently_recomputed'] == 927
    receipt = {'status': 'verified', 'full_model_states': 48, 'capacity_tests': 36,
               'state_snapshots': 927, 'readout_events': 96,
               'readout_comparison_counts': summary['comparison_counts'],
               'inference_rerun': False, 'network_required': False,
               'evidence_archive_sha256': EVIDENCE_SHA256}
    (out/'REPRODUCTION-RESULT.json').write_text(json.dumps(receipt, indent=2)+'\n')
    print(json.dumps(receipt, indent=2))

if __name__ == '__main__': main()
