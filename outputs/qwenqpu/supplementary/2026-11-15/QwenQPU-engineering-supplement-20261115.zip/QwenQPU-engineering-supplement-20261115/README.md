# QwenQPU: Supplementary Data and reproduction guide

Xi Zhao (1) and Yunlong Yu (2), 15 November 2026

1. CAS Key Laboratory of Quantum Information, University of Science and Technology of China
2. State Key Laboratory of Low Dimensional Quantum Physics, Department of Physics, Tsinghua University

This supplement accompanies **QwenQPU: A Large Language Model with an Internal Quantum Processing Unit**. It provides one offline command to verify the preserved state and control experiments and reproduce the paired normalization analysis. The original evidence archive is included byte for byte; model weights are separate.

## Verify the results offline

Requirements: Python 3.11 or later and its standard library. Run from this extracted directory:

```bash
python3 reproduce.py --out ./reproduced-check
```

Choose an output path that does not already exist. No network, GPU, credentials, or model inference is required. The command verifies the evidence archive hash, checks the 292 manifest-listed records, independently reconstructs quantum states and probabilities, and writes new reports. Expected final result:

| Check | Expected result |
|---|---:|
| Matched requests and complete-model states | 48 verified |
| Independent QPU construction tests | 36 verified |
| Initial and per-gate state snapshots | 927 verified |
| Paired raw/corrected event readouts | 96 analyzed |
| Readout error decreases / increases / ties | 48 / 15 / 33 |

Outputs are `REPRODUCTION-RESULT.json`, `state-and-control-audit/`, and `readout-audit/`. The last directory contains all 96 paired observations in `readout-events.csv` and the aggregate results in `readout-summary.json`. `expected/` preserves the corresponding analysis delivered with this manuscript.

To run only the readout analysis on an already extracted original evidence package:

```bash
python3 analyze_readout.py \
  --evidence-root ./reproduced-check/evidence \
  --out ./another-readout-check
```

## What the normalization comparison measures

This is a post-hoc paired analysis of existing outputs from 48 runs, with two correlated events per task. It is not a new benchmark, a second language generation, or an inference rerun. The uncorrected value is the native event-mass output saved before normalization. The corrected value is the recorded native QPU answer after normalization. The analysis does not replace native outputs with a host-computed formula.

Both values are compared with the same independent reference evolution. Absolute-error differences of at most `1e-12` count as ties, well below the output-digit resolution of `2^-22`. Direct floating-point comparison gives 48 decreases, 17 increases, and 31 identical errors; two of those increases are approximately `7.77e-16` and are treated as ties. Both counting conventions are retained in the JSON report.

| Absolute error | Raw readout | Corrected readout |
|---|---:|---:|
| Median | 2.384e-7 | 2.384e-7 |
| Mean | 5.772e-7 | 6.567e-7 |
| 95th percentile | 1.919e-6 | 3.290e-6 |
| Maximum | 3.195e-6 | 1.421e-5 |
| Tasks with both event errors at most 5e-5 | 48/48 | 48/48 |

Percentiles use linear interpolation at `(N-1)*q`. The correction improves 48 event errors but increases the mean and upper tail; there is no uniform precision gain. These outputs are all inside the original acceptance threshold.

The largest corrected error occurs for event A of `nonclifford-q6-g24-s4`. Its emitted total mass is `0.9999809265136719`, while the directly reconstructed stored-state norm squared is `0.9999979827740616`. The raw event probability `0.8535513877868652` is close to the independent reference `0.8535533905932728`; the corrected native output is `0.8535676002502441`. This separates total-mass readout error from actual state-norm drift. The algebraic bound for `E*(2-T)` versus `E/T` does not bound errors already present in E and T.

The 1,000-gate saved-state diagnostic is a separate experiment. Its nine corrected comparisons are not pooled with these 96 events, and the saved-state result is not a corrected end-to-end 1,000-gate rerun.

## Run the model implementation

The pinned source repository contains the compiler, ordinary-layer driver, and complete-model demonstrations:

- Repository: <https://github.com/xi-zhao/QwenQPU/tree/caae45327b46458163d0840a4c1466e5575a7b4f>
- Implementation guide: [ADDED_LAYERS.md](https://github.com/xi-zhao/QwenQPU/blob/caae45327b46458163d0840a4c1466e5575a7b4f/docs/ADDED_LAYERS.md)
- Component attribution and terms: [LICENSES.md](https://github.com/xi-zhao/QwenQPU/blob/caae45327b46458163d0840a4c1466e5575a7b4f/docs/LICENSES.md)

Obtain a fresh checkout at that exact commit:

```bash
git clone https://github.com/xi-zhao/QwenQPU qwenqpu-source
cd qwenqpu-source
git checkout --detach caae45327b46458163d0840a4c1466e5575a7b4f
```

The measured environment used PyTorch 2.6.0+cu124, Transformers 5.19.0, NumPy 2.4.6, Qiskit 2.6.1, and safetensors 0.8.0, with FP32 arithmetic and TF32 disabled. Use an environment containing the source dependencies; the offline verifier above needs none of these packages.

A small standard-layer CPU readout check is available:

```bash
python research/standard_layers/experiments/test_normalized_readout.py \
  --out ./reproduced/readout-check
```

For the complete language-model demonstration, first make the upstream checkpoint `divagr1925/Qwen3.5-4B-Qwenputer` at revision `2d9068508f2b680badb7abcded96fdd107e9ba5d` available in `./models/Qwen3.5-4B-Qwenputer`. Build the QPU prefix and run the two supplied demonstrations:

```bash
python research/standard_layers/build_prefix.py --out ./models/qpu-prefix
python research/standard_layers/demo_repaired_full_model.py \
  --base ./models/Qwen3.5-4B-Qwenputer \
  --prefix ./models/qpu-prefix \
  --out ./reproduced/added-layer-demo
```

Use fresh output paths. The prefix stores approximately 1.42 GB of tensors; the assembled FP32 weight payload is 36,671,706,112 bytes, with additional runtime memory required. The recorded full-model demonstrations used an A100 80 GB GPU. Verify prefix hashes against `evidence/added-layers/weight-manifest.json`; a mutable distribution branch is not a substitute for the recorded checkpoint identity.

The commands above correspond to the compiler, CPU check, and two complete-model demonstrations at the pinned commit. The demonstrations and the 48-task matched study are distinct workloads. Use the offline verifier to reconstruct the supplied results; rerunning the matched GPU study additionally requires the environment and paths specified below.

## Locate and identify the experiment materials

The included `QwenQPU-review-experiments-complete-20261113.zip` contains:

| Location after extraction | Purpose |
|---|---|
| `frozen-tasks.json` | Exact 48 supplied circuits and events |
| `evidence/raw/internal-*.json` | Native raw/corrected readouts, stored complex states, timings, and call counts |
| `evidence/raw/language-*.json` and `paired-*.json` | Shared language requests and paired internal/external outcomes |
| `evidence/raw/capacity-*.json` | Standalone construction tests and per-gate states |
| `evidence/raw/RESULT.json` | Completed-run status and hashes of 292 result files |
| `evidence/raw/preflight.json` | Exact source, prefix, base-weight hashes, and software versions |
| `evidence/scripts/review_experiments_v4.py` | Original experimental harness |
| `audit_final_results.py` | Independent offline state and metric verifier |

The original harness preserves its institutional-server directory layout and checkpoint paths. Its `--mode smoke` and `--mode full` commands require that recorded environment; it is retained as experimental provenance, not presented as a portable one-command GPU rerun. The portable command at the top of this document reproduces the saved-result verification and readout analysis.

Original evidence archive SHA-256:

```text
f3b9d8ea845cb160ac9470f44fb0e63b5e9b338b40bc30f33c6a8b497f09d963
```

The evidence archive is preserved byte for byte, including its historical filenames, attribution, and execution records. [PROVENANCE.md](PROVENANCE.md) explains the archived harness correction and reused controls. `MANIFEST.json` identifies the archive, analysis code, documentation, and expected outputs. The manuscript source archive is separate and contains only LaTeX and figure assets.
