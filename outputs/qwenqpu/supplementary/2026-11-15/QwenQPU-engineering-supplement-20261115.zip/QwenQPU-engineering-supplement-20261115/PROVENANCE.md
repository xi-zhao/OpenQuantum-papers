# Execution and dataset provenance

The publication-facing entry point is `README.md`. This note preserves execution history relevant to interpreting the archived records; it does not add experiments or alter results.

## Experimental identities

The execution-access ablation is the r5 dataset at QwenQPU commit `caae45327b46458163d0840a4c1466e5575a7b4f`. The matched-executor and state-diagnostic dataset is identified internally as `formal-02`, completed on 12 November 2026 at 16:43:01 UTC. Both use the frozen tasks and QPU prefix identities reported in Appendix A.

The included complete evidence archive has SHA-256 `f3b9d8ea845cb160ac9470f44fb0e63b5e9b338b40bc30f33c6a8b497f09d963`. Its underlying downloaded evidence archive has SHA-256 `67f03da21b7f4a4e43733546d80fe7cc5c5f72d8ab755363cd57041ea9dbb759`. The completed-run manifest `evidence/raw/RESULT.json` has SHA-256 `7b7138bd9a56db4733511f84da98300bb64cf32e85851ff1df6381c93b7429ce` and identifies 292 result files.

## Harness correction and control reuse

The first harness attempt stopped before the paired task run because it imported the standalone normalizer instead of the merged-model adapter used by the execution-access benchmark. The corrected harness uses the hash-verified r5 adapter. Model weights, tasks, seeds, and scoring thresholds were unchanged. This was an interface correction, not regeneration or exclusion of an unfavorable paired benchmark answer.

`evidence/raw/inherited-controls.json` identifies 88 completed control files reused byte for byte: 39 capacity/construction files and 49 external-replay/summary files. These observations are counted once, in their corresponding analyses, and are not relabeled as new complete-model executions. The manifest records the changed function, previous protocol and preflight identities, and each inherited file hash.

The earlier failure record is identified by SHA-256 `e6b7eea76eded8d5204f8e04a6c6871e8d8e5ca8f4e34ee6ef009854ff4b03f8`. The inheritance manifest states that this record remains in its original server run directory; the compact package does not claim to contain the complete earlier failed run.

## Immutable historical documentation

The nested archive retains its original report, usage notes, filenames, author labels, and operational descriptions. These describe the evidence package at the time it was assembled and do not replace the current article's authors or publication information. The manuscript is authored by Xi Zhao and Yunlong Yu. The current reproduction guide distinguishes offline verification from model inference and identifies the server-layout dependency of the archived GPU harness.
