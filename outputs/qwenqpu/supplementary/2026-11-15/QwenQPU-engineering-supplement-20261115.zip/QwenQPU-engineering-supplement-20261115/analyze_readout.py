"""Paired readout audit of preserved model outputs; Python standard library only."""
from pathlib import Path
import argparse
import csv
import hashlib
import importlib.util
import json
import math
import statistics

TOLERANCE = 5e-5
TIE_TOLERANCE = 1e-12

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def percentile(values, q):
    values = sorted(values)
    pos = (len(values) - 1) * q
    lo = math.floor(pos); hi = math.ceil(pos)
    return values[lo] + (values[hi] - values[lo]) * (pos - lo)

def describe(rows, key):
    values = [r[key] for r in rows]
    return {'mean': statistics.mean(values), 'median': statistics.median(values),
            'p95_linear': percentile(values, .95), 'maximum': max(values),
            'events_within_5e_minus5': sum(v <= TOLERANCE for v in values),
            'tasks_with_both_events_within_5e_minus5': sum(
                all(r[key] <= TOLERANCE for r in rows if r['task_id'] == task_id)
                for task_id in {r['task_id'] for r in rows})}

def analyze(root, output):
    root = Path(root).resolve(); output = Path(output).resolve()
    assert not output.exists(), 'Choose a new output directory.'
    raw = root / 'evidence/raw'
    result_path = raw / 'RESULT.json'
    assert sha(result_path) == '7b7138bd9a56db4733511f84da98300bb64cf32e85851ff1df6381c93b7429ce'
    manifest = json.loads(result_path.read_text())
    assert manifest['status'] == 'completed' and manifest['mode'] == 'full'
    for name, record in manifest['files'].items():
        assert Path(name).name == name
        p = raw / name
        assert p.stat().st_size == record['bytes'] and sha(p) == record['sha256'], name
    task_path = root / 'frozen-tasks.json'
    assert sha(task_path) == 'b6d892f5441f7b66fcc63d3c4a194188b5b84c410376225ae9d779feb01d0759'
    tasks = json.loads(task_path.read_text())
    spec = importlib.util.spec_from_file_location('state_audit', root / 'audit_final_results.py')
    audit = importlib.util.module_from_spec(spec); spec.loader.exec_module(audit)
    rows = []
    for task in tasks:
        p = raw / ('internal-' + task['id'] + '.json')
        d = json.loads(p.read_text())
        live = json.loads((raw / ('language-' + task['id'] + '.json')).read_text())
        assert live['request'] == {'circuit': task['circuit'], 'events': task['events']}
        ref = audit.reference(task['circuit'], 6)
        for event, wires in task['events'].items():
            expected = math.fsum(abs(v)**2 for i, v in enumerate(ref)
                if all((i >> int(q)) & 1 == bit for q, bit in wires.items()))
            saved = d['raw_readouts'][event]
            uncorrected = saved['raw_event_probability']
            corrected = d['answer']['probabilities'][event]
            total = saved['raw_total_probability']
            assert saved['probability'] == corrected
            assert abs(total - 1) <= 5e-4
            raw_error = abs(uncorrected - expected)
            corrected_error = abs(corrected - expected)
            delta = corrected_error - raw_error
            outcome = 'improved' if delta < -TIE_TOLERANCE else 'worsened' if delta > TIE_TOLERANCE else 'tied_within_1e-12'
            state_norm = d['state_metrics']['norm_squared']
            rows.append({'task_id': task['id'], 'family': 'nonclifford' if task['id'].startswith('nonclifford') else 'clifford',
                'event': event, 'logical_qubits': task['qubits'], 'gates': task['gate_count'],
                'reference_probability': expected, 'uncorrected_probability': uncorrected,
                'corrected_probability': corrected, 'emitted_total_mass': total,
                'stored_state_norm_squared': state_norm, 'emitted_total_minus_state_norm': total - state_norm,
                'host_formula_diagnostic_only': uncorrected * (2 - total),
                'raw_absolute_error': raw_error, 'corrected_absolute_error': corrected_error,
                'error_change': delta, 'outcome': outcome, 'source_file': p.relative_to(root).as_posix(),
                'source_sha256': sha(p)})
    assert len(tasks) == 48 and len(rows) == 96
    counts = {name: sum(r['outcome'] == name for r in rows)
              for name in ['improved', 'worsened', 'tied_within_1e-12']}
    strict_counts = {'improved': sum(r['error_change'] < 0 for r in rows),
                     'worsened': sum(r['error_change'] > 0 for r in rows),
                     'unchanged': sum(r['error_change'] == 0 for r in rows)}
    summary = {'analysis': 'Post-hoc paired readout analysis of existing runs; no inference rerun.',
        'tasks': len(tasks), 'events': len(rows), 'events_per_task': 2,
        'independence': 'Two correlated events per task; 96 events are not 96 independent runs.',
        'source_result_sha256': sha(result_path), 'frozen_tasks_sha256': sha(task_path),
        'comparison_tie_absolute_tolerance': TIE_TOLERANCE, 'comparison_counts': counts,
        'strict_float_comparison_counts': strict_counts,
        'tie_note': 'Two strict increases are 7.77e-16 reference-roundoff differences and are counted as ties at 1e-12.',
        'raw': describe(rows, 'raw_absolute_error'), 'corrected': describe(rows, 'corrected_absolute_error'),
        'families': {f: {'events': sum(r['family'] == f for r in rows),
                        'raw': describe([r for r in rows if r['family'] == f], 'raw_absolute_error'),
                        'corrected': describe([r for r in rows if r['family'] == f], 'corrected_absolute_error')}
                     for f in ['clifford', 'nonclifford']},
        'worst_corrected_events': sorted(rows, key=lambda r: r['corrected_absolute_error'], reverse=True)[:5],
        'maximum_raw_total_vs_state_norm_difference': max(abs(r['emitted_total_minus_state_norm']) for r in rows),
        'interpretation': 'Correction improves 48 event errors, worsens 15, and leaves 33 unchanged within 1e-12. Mean and maximum absolute errors increase; both readouts retain all task probability passes.',
        'native_outputs': 'Corrected values are the recorded native model outputs, not host-side recomputations of E*(2-T).',
        'percentile_method': 'Linear interpolation at index (N-1)*q; descriptive only.'}
    output.mkdir(parents=True)
    with (output / 'readout-events.csv').open('x', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    (output / 'readout-summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k: summary[k] for k in ['tasks','events','comparison_counts','raw','corrected']}, indent=2))
    return summary

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence-root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    analyze(args.evidence_root, args.out)
